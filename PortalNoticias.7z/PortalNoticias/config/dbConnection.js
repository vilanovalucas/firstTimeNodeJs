//Instancia o módulo "mysql"
var mysql = require('mysql');

var connMySQL = function () {

    //Instancia o banco de dados inserindo as credenciais

    //CASA
    //return mysql.createConnection({
    //     host: 'localhost',
    //     user: 'root',
    //     password: '1234',
    //     database: 'portal_noticias'
    // });

    //TRABALHO
    return mysql.createConnection({
        host: '192.168.10.213',
        user: 'desenvolvimento',
        password: 'D3s3nv0lv1m3nt0',
        database: 'rodriguesdb1'
    });
}

module.exports = function () {
    console.log('DB CONNECTION STATUS: CONNECTED')
    return connMySQL;
}
//Para conectar no banco no trabalho: mysql -h 192.168.10.213 -u desenvolvimento -p