console.log('FILE "news" INITIALIZED');

var http = require('http');

var server = http.createServer(function (req, res) {

    var category = req.url;

    if (category == "/technology") {
        res.end("<html><body>Technology News</body></html>");
        console.log('PAGE LOADED: "Technology"')
    } else if (category == "/beauty") {
        res.end("<html><body>Beauty News</body></html>");
        console.log('PAGE LOADED: "Beauty"')
    } else if (category == "/economy") {
        res.end("<html><body>Economy News</body></html>");
        console.log('PAGE LOADED: "Economy"')
    } else {
        res.end("<html><body>News Portal</body></html>");
        console.log('MAIN PAGE LOADED')
    }
}).listen(3001);