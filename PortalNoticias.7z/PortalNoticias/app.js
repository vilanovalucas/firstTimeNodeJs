//Instancia o servidor
var app = require('./config/server');
//Define a porta do servidor
var serverPort = 3000;

//Inicia o servidor definindo a porta a ser escutada
app.listen(serverPort,function(){
    console.log(`PORT ${serverPort} STATUS: LISTENING`);
})