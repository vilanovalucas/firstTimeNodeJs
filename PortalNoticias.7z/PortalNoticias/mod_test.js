//Exportation of module content
module.exports = ()=>{
    var msg = "Este módulo contém apenas uma string";
    return msg;
}