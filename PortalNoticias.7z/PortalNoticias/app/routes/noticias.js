// var dbConnection = require('../../config/dbConnection');

module.exports = function (app) {

    //Define a rota e seu conteúdo
    app.get('/noticias', function (req, res) {

        var connection = app.config.dbConnection();

        //Executa uma query sobre o banco instanciado
        connection.query('select * from noticias;', function (error, result) {
            //Define o retorno do banco
            res.render("noticias/noticias",{noticias: result});
            console.log(`ERROR STATUS : ${error}`);
        });
        //Define o render do arquivo
        //res.render("noticias/noticias");
    });
};