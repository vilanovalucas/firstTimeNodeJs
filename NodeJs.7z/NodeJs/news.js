
console.log('Server status: OK');
let http = require('http');

let server = http.createServer( (req, res) => {

    let categoria = req.url;

    if(categoria == '/technology'){
        res.end("<http><body>Technology news</body></html>");
    }else if(categoria == '/fashion'){
        res.end("<http><body>Fashion news</body></html>");
    }else if(categoria == '/beauty'){
        res.end("<http><body>Beauty news</body></html>");
    }else{
        res.end("<http><body>News portal</body></html>");
    }

} ).listen(3000);