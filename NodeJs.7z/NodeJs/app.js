let express = require('express')();
/* o require do express retorna uma função que não é utilizada. para utilizá-la, basta inserir os 
parâmetros logo após o require em si, como foi feito acima */

express.listen(3000, ()=>{
    console.log('Server status: OK');
    console.log('Express status: OK');
});